package com.tfar.dankstorage.container;

import com.tfar.dankstorage.inventory.DankHandler;
import com.tfar.dankstorage.tile.AbstractDankStorageTile;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public abstract class AbstractDankContainer extends AbstractAbstractDankContainer {

  public AbstractDankStorageTile te;


  public AbstractDankContainer(World world, BlockPos pos, InventoryPlayer playerInventory, EntityPlayer player, DankHandler handler, int rows) {
    super(playerInventory,player,handler,rows);
    this.te = (AbstractDankStorageTile) world.func_175625_s(pos);
    te.openInventory(player);
  }

  @Override
  public void func_75134_a(EntityPlayer playerIn) {
    super.func_75134_a(playerIn);
    this.te.closeInventory(playerIn);
  }
}

