package com.tfar.dankstorage.container;

import com.tfar.dankstorage.inventory.LockedSlot;
import com.tfar.dankstorage.inventory.PortableDankHandler;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public abstract class AbstractPortableDankContainer extends AbstractAbstractDankContainer {

  protected ItemStack bag;

  public AbstractPortableDankContainer(InventoryPlayer playerInventory, EntityPlayer player, PortableDankHandler handler, int rows) {
    super(playerInventory,player,handler,rows);
    this.bag = player.func_184614_ca();
    addPlayerSlots(playerInventory, playerInventory.field_70461_c);
  }

  @Override
  protected void addPlayerSlots(IInventory playerinventory) {}

  protected void addPlayerSlots(IInventory playerinventory, int locked) {
    int yStart = 50;
    switch (rows){
      case 9:yStart +=59;
      case 6:yStart +=18;
      case 5:yStart +=18;
      case 4:yStart +=20;
      case 3:yStart +=16;
      case 2:yStart +=18;
    }
    for (int row = 0; row < 3; ++row) {
      for (int col = 0; col < 9; ++col) {
        int x = 8 + col * 18;
        int y = row * 18 + yStart;
        this.func_75146_a(new Slot(playerinventory, col + row * 9 + 9, x, y) {
          @Override
          public int func_178170_b(ItemStack stack) {
            return Math.min(this.func_75219_a(), stack.func_77976_d());
          }
        });
      }
    }

    for (int row = 0; row < 9; ++row) {
      int x = 8 + row * 18;
      int y = yStart + 58;
      if (row != locked)
      this.func_75146_a(new Slot(playerinventory, row, x, y) {
        @Override
        public int func_178170_b(ItemStack stack) {
          return Math.min(this.func_75219_a(), stack.func_77976_d());
        }
      });
      else
        this.func_75146_a(new LockedSlot(playerinventory, row, x, y) {
        @Override
        public int func_178170_b(ItemStack stack) {
          return Math.min(this.func_75219_a(), stack.func_77976_d());
        }
      });
    }
  }

  @Override
  public void func_75142_b() {
    super.func_75142_b();
    ((PortableDankHandler)handler).writeItemStack();
  }
}

