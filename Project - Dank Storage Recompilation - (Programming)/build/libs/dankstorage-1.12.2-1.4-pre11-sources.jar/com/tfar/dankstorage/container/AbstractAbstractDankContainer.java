package com.tfar.dankstorage.container;

import com.google.common.collect.Sets;
import com.tfar.dankstorage.inventory.DankHandler;
import com.tfar.dankstorage.inventory.DankSlot;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.inventory.*;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.server.SPacketSetSlot;

import javax.annotation.Nullable;
import java.util.Set;

public abstract class AbstractAbstractDankContainer extends Container {

  public DankHandler handler;

  /**
   * The current drag mode (0 : evenly split, 1 : one item by slot, 2 : not used ?)
   */
  protected int dragMode = -1;
  /**
   * The current drag event (0 : start, 1 : add slot : 2 : end)
   */
  protected int dragEvent;
  /**
   * The list of slots where the itemstack holds will be distributed
   */
  protected final Set<Slot> dragSlots = Sets.newHashSet();

  public final int rows;

  public AbstractAbstractDankContainer(InventoryPlayer playerInventory, EntityPlayer player, DankHandler handler, int rows) {
    this.rows = rows;
    this.handler = handler;
    addOwnSlots(rows);
    addPlayerSlots(playerInventory);
  }

  public void addOwnSlots(int rows) {
    DankHandler handler = this.handler;
    int slotIndex = 0;
    for (int row = 0; row < rows; ++row) {
      for (int col = 0; col < 9; ++col) {
        int x = 8 + col * 18;
        int y = row * 18 + 18;
        if (rows == 9)y += 5;
        this.func_75146_a(new DankSlot(handler, slotIndex, x, y));
        slotIndex++;
      }
    }
  }

  protected void addPlayerSlots(IInventory playerinventory) {
    int yStart = 50;
    switch (rows){
      case 9:yStart +=59;
      case 6:yStart +=18;
      case 5:yStart +=18;
      case 4:yStart +=20;
      case 3:yStart +=16;
      case 2:yStart +=18;
    }
    for (int row = 0; row < 3; ++row) {
      for (int col = 0; col < 9; ++col) {
        int x = 8 + col * 18;
        int y = row * 18 + yStart;
        this.func_75146_a(new Slot(playerinventory, col + row * 9 + 9, x, y) {
          @Override
          public int func_178170_b(ItemStack stack) {
            return Math.min(this.func_75219_a(), stack.func_77976_d());
          }
        });
      }
    }

    for (int row = 0; row < 9; ++row) {
      int x = 8 + row * 18;
      int y = yStart + 58;
      this.func_75146_a(new Slot(playerinventory, row, x, y) {
        @Override
        public int func_178170_b(ItemStack stack) {
          return Math.min(this.func_75219_a(), stack.func_77976_d());
        }
      });
    }
  }

  @Override
  public ItemStack func_82846_b(EntityPlayer playerIn, int index) {
    ItemStack itemstack = ItemStack.field_190927_a;
    Slot slot = this.field_75151_b.get(index);

    if (slot != null && slot.func_75216_d()) {
      ItemStack itemstack1 = slot.func_75211_c();
      itemstack = itemstack1.func_77946_l();

      if (index < rows * 9) {
        if (!this.func_75135_a(itemstack1, rows * 9, this.field_75151_b.size(), true)) {
          return ItemStack.field_190927_a;
        }
      } else if (!this.func_75135_a(itemstack1, 0, rows * 9, false)) {
        return ItemStack.field_190927_a;
      }

      if (itemstack1.func_190926_b()) {
        slot.func_75215_d(ItemStack.field_190927_a);
      } else {
        slot.func_75218_e();
      }
    }

    return itemstack;
  }

  @Override
  public ItemStack func_184996_a(int slotId, int dragType, ClickType clickTypeIn, EntityPlayer player) {
    ItemStack itemstack = ItemStack.field_190927_a;
    InventoryPlayer PlayerInventory = player.field_71071_by;

    if (clickTypeIn == ClickType.QUICK_CRAFT) {
      int j1 = this.dragEvent;
      this.dragEvent = func_94532_c(dragType);

      if ((j1 != 1 || this.dragEvent != 2) && j1 != this.dragEvent) {
        this.func_94533_d();
      } else if (PlayerInventory.func_70445_o().func_190926_b()) {
        this.func_94533_d();
      } else if (this.dragEvent == 0) {
        this.dragMode = func_94529_b(dragType);

        if (func_180610_a(this.dragMode, player)) {
          this.dragEvent = 1;
          this.dragSlots.clear();
        } else {
          this.func_94533_d();
        }
      } else if (this.dragEvent == 1) {
        Slot slot7 = this.field_75151_b.get(slotId);
        ItemStack mouseStack = PlayerInventory.func_70445_o();

        if (slot7 != null && AbstractDankContainer.canAddItemToSlot(slot7, mouseStack, true) && slot7.func_75214_a(mouseStack) && (this.dragMode == 2 || mouseStack.func_190916_E() > this.dragSlots.size()) && this.func_94531_b(slot7)) {
          this.dragSlots.add(slot7);
        }
      } else if (this.dragEvent == 2) {
        if (!this.dragSlots.isEmpty()) {
          ItemStack mouseStackCopy = PlayerInventory.func_70445_o().func_77946_l();
          int k1 = PlayerInventory.func_70445_o().func_190916_E();

          for (Slot dragSlot : this.dragSlots) {
            ItemStack mouseStack = PlayerInventory.func_70445_o();

            if (dragSlot != null && AbstractAbstractDankContainer.canAddItemToSlot(dragSlot, mouseStack, true) && dragSlot.func_75214_a(mouseStack) && (this.dragMode == 2 || mouseStack.func_190916_E() >= this.dragSlots.size()) && this.func_94531_b(dragSlot)) {
              ItemStack itemstack14 = mouseStackCopy.func_77946_l();
              int j3 = dragSlot.func_75216_d() ? dragSlot.func_75211_c().func_190916_E() : 0;
              func_94525_a(this.dragSlots, this.dragMode, itemstack14, j3);
              int k3 = dragSlot.func_178170_b(itemstack14);

              if (itemstack14.func_190916_E() > k3) {
                itemstack14.func_190920_e(k3);
              }

              k1 -= itemstack14.func_190916_E() - j3;
              dragSlot.func_75215_d(itemstack14);
            }
          }

          mouseStackCopy.func_190920_e(k1);
          PlayerInventory.func_70437_b(mouseStackCopy);
        }

        this.func_94533_d();
      } else {
        this.func_94533_d();
      }
    } else if (this.dragEvent != 0) {
      this.func_94533_d();
    } else if ((clickTypeIn == ClickType.PICKUP || clickTypeIn == ClickType.QUICK_MOVE) && (dragType == 0 || dragType == 1)) {
      if (slotId == -999) {
        if (!PlayerInventory.func_70445_o().func_190926_b()) {
          if (dragType == 0) {
            player.func_71019_a(PlayerInventory.func_70445_o(), true);
            PlayerInventory.func_70437_b(ItemStack.field_190927_a);
          }

          if (dragType == 1) {
            player.func_71019_a(PlayerInventory.func_70445_o().func_77979_a(1), true);
          }
        }
      } else if (clickTypeIn == ClickType.QUICK_MOVE) {
        if (slotId < 0) {
          return ItemStack.field_190927_a;
        }

        Slot slot5 = this.field_75151_b.get(slotId);

        if (slot5 == null || !slot5.func_82869_a(player)) {
          return ItemStack.field_190927_a;
        }

        for (ItemStack itemstack7 = this.func_82846_b(player, slotId); !itemstack7.func_190926_b() && ItemStack.func_179545_c(slot5.func_75211_c(), itemstack7); itemstack7 = this.func_82846_b(player, slotId)) {
          itemstack = itemstack7.func_77946_l();
        }
      } else {
        if (slotId < 0) {
          return ItemStack.field_190927_a;
        }

        Slot slot6 = this.field_75151_b.get(slotId);

        if (slot6 != null) {
          ItemStack slotStack = slot6.func_75211_c();
          ItemStack mouseStack = PlayerInventory.func_70445_o();

          if (!slotStack.func_190926_b()) {
            itemstack = slotStack.func_77946_l();
          }

          if (slotStack.func_190926_b()) {
            if (!mouseStack.func_190926_b() && slot6.func_75214_a(mouseStack)) {
              int i3 = dragType == 0 ? mouseStack.func_190916_E() : 1;

              if (i3 > slot6.func_178170_b(mouseStack)) {
                i3 = slot6.func_178170_b(mouseStack);
              }

              slot6.func_75215_d(mouseStack.func_77979_a(i3));
            }
          } else if (slot6.func_82869_a(player)) {
            if (mouseStack.func_190926_b()) {
              if (slotStack.func_190926_b()) {
                slot6.func_75215_d(ItemStack.field_190927_a);
                PlayerInventory.func_70437_b(ItemStack.field_190927_a);
              } else {
                int l2 = dragType == 0 ? slotStack.func_190916_E() : (slotStack.func_190916_E() + 1) / 2;
                PlayerInventory.func_70437_b(slot6.func_75209_a(l2));

                if (slotStack.func_190926_b()) {
                  slot6.func_75215_d(ItemStack.field_190927_a);
                }

                slot6.func_190901_a(player, PlayerInventory.func_70445_o());
              }
            } else if (slot6.func_75214_a(mouseStack)) {
              if (slotStack.func_77973_b() == mouseStack.func_77973_b() && slotStack.func_77960_j() == mouseStack.func_77960_j() && ItemStack.func_77970_a(slotStack, mouseStack)) {
                int k2 = dragType == 0 ? mouseStack.func_190916_E() : 1;

                if (k2 > slot6.func_178170_b(mouseStack) - slotStack.func_190916_E()) {
                  k2 = slot6.func_178170_b(mouseStack) - slotStack.func_190916_E();
                }

                mouseStack.func_190918_g(k2);
                slotStack.func_190917_f(k2);
              } else if (mouseStack.func_190916_E() <= slot6.func_178170_b(mouseStack) /*&& slotStack.getCount() <= slotStack.getMaxStackSize()*/) {
                slot6.func_75215_d(mouseStack);
                PlayerInventory.func_70437_b(slotStack);
              }
            } else if (slotStack.func_77973_b() == mouseStack.func_77973_b() && mouseStack.func_77976_d() > 1 && (!slotStack.func_77981_g() || slotStack.func_77960_j() == mouseStack.func_77960_j()) && ItemStack.func_77970_a(slotStack, mouseStack) && !slotStack.func_190926_b()) {
              int j2 = slotStack.func_190916_E();

              if (j2 + mouseStack.func_190916_E() <= mouseStack.func_77976_d()) {
                mouseStack.func_190917_f(j2);
                slotStack = slot6.func_75209_a(j2);

                if (slotStack.func_190926_b()) {
                  slot6.func_75215_d(ItemStack.field_190927_a);
                }

                slot6.func_190901_a(player, PlayerInventory.func_70445_o());
              }
            }
          }

          slot6.func_75218_e();
        }
      }
    } else if (clickTypeIn == ClickType.SWAP && dragType >= 0 && dragType < 9) {
      Slot slot4 = this.field_75151_b.get(slotId);
      ItemStack itemstack6 = PlayerInventory.func_70301_a(dragType);
      ItemStack slotStack = slot4.func_75211_c();

      if (!itemstack6.func_190926_b() || !slotStack.func_190926_b()) {
        if (itemstack6.func_190926_b()) {
          if (slot4.func_82869_a(player)) {
            int maxAmount = slotStack.func_77976_d();
            if (slotStack.func_190916_E() > maxAmount) {
              ItemStack newSlotStack = slotStack.func_77946_l();
              ItemStack takenStack = newSlotStack.func_77979_a(maxAmount);
              PlayerInventory.func_70299_a(dragType, takenStack);
              //slot4.onSwapCraft(takenStack.getCount());
              slot4.func_75215_d(newSlotStack);
              slot4.func_190901_a(player, takenStack);
            } else {
              PlayerInventory.func_70299_a(dragType, slotStack);
              //slot4.onSwapCraft(slotStack.getCount());
              slot4.func_75215_d(ItemStack.field_190927_a);
              slot4.func_190901_a(player, slotStack);
            }
          }
        } else if (slotStack.func_190926_b()) {
          if (slot4.func_75214_a(itemstack6)) {
            int l1 = slot4.func_178170_b(itemstack6);

            if (itemstack6.func_190916_E() > l1) {
              slot4.func_75215_d(itemstack6.func_77979_a(l1));
            } else {
              slot4.func_75215_d(itemstack6);
              PlayerInventory.func_70299_a(dragType, ItemStack.field_190927_a);
            }
          }
        } else if (slot4.func_82869_a(player) && slot4.func_75214_a(itemstack6)) {
          int i2 = slot4.func_178170_b(itemstack6);

          if (itemstack6.func_190916_E() > i2) {
            slot4.func_75215_d(itemstack6.func_77979_a(i2));
            slot4.func_190901_a(player, slotStack);

            if (!PlayerInventory.func_70441_a(slotStack)) {
              player.func_71019_a(slotStack, true);
            }
          } else {
            slot4.func_75215_d(itemstack6);
            if (slotStack.func_190916_E() > slotStack.func_77976_d()) {
              ItemStack remainder = slotStack.func_77946_l();
              PlayerInventory.func_70299_a(dragType, remainder.func_77979_a(slotStack.func_77976_d()));
              if (!PlayerInventory.func_70441_a(remainder)) {
                player.func_71019_a(remainder, true);
              }
            } else {
              PlayerInventory.func_70299_a(dragType, slotStack);
            }
            slot4.func_190901_a(player, slotStack);
          }
        }
      }
    } else if (clickTypeIn == ClickType.CLONE && player.field_71075_bZ.field_75098_d && PlayerInventory.func_70445_o().func_190926_b() && slotId >= 0) {
      Slot slot3 = this.field_75151_b.get(slotId);

      if (slot3 != null && slot3.func_75216_d()) {
        ItemStack itemstack5 = slot3.func_75211_c().func_77946_l();
        itemstack5.func_190920_e(itemstack5.func_77976_d());
        PlayerInventory.func_70437_b(itemstack5);
      }
    } else if (clickTypeIn == ClickType.THROW && PlayerInventory.func_70445_o().func_190926_b() && slotId >= 0) {
      Slot slot2 = this.field_75151_b.get(slotId);

      if (slot2 != null && slot2.func_75216_d() && slot2.func_82869_a(player)) {
        ItemStack itemstack4 = slot2.func_75209_a(dragType == 0 ? 1 : slot2.func_75211_c().func_190916_E());
        slot2.func_190901_a(player, itemstack4);
        player.func_71019_a(itemstack4, true);
      }
    } else if (clickTypeIn == ClickType.PICKUP_ALL && slotId >= 0) {
      Slot slot = this.field_75151_b.get(slotId);
      ItemStack mouseStack = PlayerInventory.func_70445_o();

      if (!mouseStack.func_190926_b() && (slot == null || !slot.func_75216_d() || !slot.func_82869_a(player))) {
        int i = dragType == 0 ? 0 : this.field_75151_b.size() - 1;
        int j = dragType == 0 ? 1 : -1;

        for (int k = 0; k < 2; ++k) {
          for (int l = i; l >= 0 && l < this.field_75151_b.size() && mouseStack.func_190916_E() < mouseStack.func_77976_d(); l += j) {
            Slot slot1 = this.field_75151_b.get(l);

            if (slot1.func_75216_d() && AbstractDankContainer.canAddItemToSlot(slot1, mouseStack, true) && slot1.func_82869_a(player) && this.func_94530_a(mouseStack, slot1)) {
              ItemStack itemstack2 = slot1.func_75211_c();

              if (k != 0 || itemstack2.func_190916_E() < slot1.func_178170_b(itemstack2)) {
                int i1 = Math.min(mouseStack.func_77976_d() - mouseStack.func_190916_E(), itemstack2.func_190916_E());
                ItemStack itemstack3 = slot1.func_75209_a(i1);
                mouseStack.func_190917_f(i1);

                if (itemstack3.func_190926_b()) {
                  slot1.func_75215_d(ItemStack.field_190927_a);
                }

                slot1.func_190901_a(player, itemstack3);
              }
            }
          }
        }
      }

      this.func_75142_b();
    }

    if (itemstack.func_190916_E() > 64) {
      itemstack = itemstack.func_77946_l();
      itemstack.func_190920_e(64);
    }

    return itemstack;
  }

  @Override
  public boolean func_75145_c(EntityPlayer playerIn) {
    return true;
  }

  @Override
  protected boolean func_75135_a(ItemStack stack, int startIndex, int endIndex, boolean reverseDirection) {
    boolean flag = false;
    int i = startIndex;

    if (reverseDirection) {
      i = endIndex - 1;
    }

    while (!stack.func_190926_b()) {
      if (reverseDirection) {
        if (i < startIndex) break;
      } else {
        if (i >= endIndex) break;
      }

      Slot slot = this.field_75151_b.get(i);
      ItemStack itemstack = slot.func_75211_c();

      if (!itemstack.func_190926_b() && itemstack.func_77973_b() == stack.func_77973_b() && (stack.func_77960_j() == itemstack.func_77960_j()) && ItemStack.func_77970_a(stack, itemstack)) {
        int j = itemstack.func_190916_E() + stack.func_190916_E();
        int maxSize = slot.func_178170_b(itemstack);

        if (j <= maxSize) {
          stack.func_190920_e(0);
          itemstack.func_190920_e(j);
          slot.func_75218_e();
          flag = true;
        } else if (itemstack.func_190916_E() < maxSize) {
          stack.func_190918_g(maxSize - itemstack.func_190916_E());
          itemstack.func_190920_e(maxSize);
          slot.func_75218_e();
          flag = true;
        }
      }

      i += (reverseDirection) ? -1 : 1;
    }

    if (!stack.func_190926_b()) {
      if (reverseDirection) i = endIndex - 1;
      else i = startIndex;

      while (true) {
        if (reverseDirection) {
          if (i < startIndex) break;
        } else {
          if (i >= endIndex) break;
        }

        Slot slot1 = this.field_75151_b.get(i);
        ItemStack itemstack1 = slot1.func_75211_c();

        if (itemstack1.func_190926_b() && slot1.func_75214_a(stack)) {
          if (stack.func_190916_E() > slot1.func_178170_b(stack)) {
            slot1.func_75215_d(stack.func_77979_a(slot1.func_178170_b(stack)));
          } else {
            slot1.func_75215_d(stack.func_77979_a(stack.func_190916_E()));
          }

          slot1.func_75218_e();
          flag = true;
          break;
        }

        i += (reverseDirection) ? -1 : 1;
      }
    }

    return flag;
  }

  @Override
  protected void func_94533_d() {
    this.dragEvent = 0;
    this.dragSlots.clear();
  }
  public static boolean canAddItemToSlot(@Nullable Slot slot, ItemStack stack, boolean stackSizeMatters) {
    boolean flag = slot == null || !slot.func_75216_d();
    ItemStack slotStack = slot.func_75211_c();

    if (!flag && stack.func_77969_a(slotStack) && ItemStack.func_77970_a(slotStack, stack)) {
      return slotStack.func_190916_E() + (stackSizeMatters ? 0 : stack.func_190916_E()) <= slot.func_178170_b(slotStack);
    }
    return flag;
  }

  @Override
  public void func_75142_b() {
    for (int i = 0; i < this.field_75151_b.size(); ++i) {
      ItemStack itemstack = (this.field_75151_b.get(i)).func_75211_c();
      ItemStack itemstack1 = this.field_75153_a.get(i);

      if (!ItemStack.func_77989_b(itemstack1, itemstack)) {
        itemstack1 = itemstack.func_190926_b() ? ItemStack.field_190927_a : itemstack.func_77946_l();
        this.field_75153_a.set(i, itemstack1);
      }
    }
  }

  @Override
  public void func_75132_a(IContainerListener listener) {
    if (this.field_75149_d.contains(listener)) {
      throw new IllegalArgumentException("Listener already listening");
    } else {
      this.field_75149_d.add(listener);
      if (listener instanceof EntityPlayerMP) {
        EntityPlayerMP player = (EntityPlayerMP) listener;
        player.field_71135_a.func_147359_a(new SPacketSetSlot(-1, -1, player.field_71071_by.func_70445_o()));
      }
      this.func_75142_b();
    }
  }
}

