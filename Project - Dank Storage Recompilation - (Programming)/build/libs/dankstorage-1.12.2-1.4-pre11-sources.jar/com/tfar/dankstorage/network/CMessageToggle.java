package com.tfar.dankstorage.network;

import com.tfar.dankstorage.block.DankItemBlock;
import com.tfar.dankstorage.util.Utils;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;


public class CMessageToggle implements IMessage {

  public CMessageToggle() {}

  public static final KeybindToggleType[] keys = KeybindToggleType.values();
  KeybindToggleType key;

  public CMessageToggle(KeybindToggleType key){
    this.key = key;
  }

  /**
   * Convert from the supplied buffer into your specific message type
   *
   * @param buf
   */
  @Override
  public void fromBytes(ByteBuf buf) {
    this.key = keys[buf.readInt()];
  }

  /**
   * Deconstruct your message into the supplied byte buffer
   *
   * @param buf
   */
  @Override
  public void toBytes(ByteBuf buf) {buf.writeInt(key.ordinal());}

  public static class Handler implements IMessageHandler<CMessageToggle, IMessage> {
    @Override
    public IMessage onMessage(CMessageToggle message, MessageContext ctx) {
      FMLCommonHandler.instance().getWorldThread(ctx.netHandler).func_152344_a(() -> handle(message,ctx));
      return null;
    }

    private void handle(CMessageToggle mess,MessageContext ctx) {
      EntityPlayer player = ctx.getServerHandler().field_147369_b;
      ItemStack bag = player.func_184614_ca();
      if (!(bag.func_77973_b() instanceof DankItemBlock)){
        bag = player.func_184592_cb();
        if (!(bag.func_77973_b() instanceof DankItemBlock))return;
      }
      Utils.toggle(bag, mess.key, player);
    }
  }

  public enum KeybindToggleType {
    PICKUP,VOID,CONSTRUCTION;
    KeybindToggleType(){}
  }
}
