package com.tfar.dankstorage.network;

import com.tfar.dankstorage.DankStorage;
import com.tfar.dankstorage.block.DankItemBlock;
import com.tfar.dankstorage.inventory.PortableDankHandler;
import com.tfar.dankstorage.util.Utils;
import io.netty.buffer.ByteBuf;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class CMessagePickBlock implements IMessage {

  public CMessagePickBlock() {
  }


  /**
   * Convert from the supplied buffer into your specific message type
   *
   * @param buf
   */
  @Override
  public void fromBytes(ByteBuf buf) {
  }

  /**
   * Deconstruct your message into the supplied byte buffer
   *
   * @param buf
   */
  @Override
  public void toBytes(ByteBuf buf) {
  }

  public static class Handler implements IMessageHandler<CMessagePickBlock, IMessage> {
    @Override
    public IMessage onMessage(CMessagePickBlock message, MessageContext ctx) {
      FMLCommonHandler.instance().getWorldThread(ctx.netHandler).func_152344_a(() -> handle(ctx));
      return null;
    }

    private void handle(MessageContext ctx) {

      EntityPlayer player = ctx.getServerHandler().field_147369_b;
      ItemStack bag = player.func_184614_ca();
      if (bag.func_77973_b() instanceof DankItemBlock) {
        PortableDankHandler handler = Utils.getHandler(bag);
        ItemStack pickblock = onPickBlock(Minecraft.func_71410_x().field_71476_x, player, player.field_70170_p);
        int slot = -1;
        if (!pickblock.func_190926_b())
          for (int i = 0; i < handler.getSlots(); i++) {
            if (pickblock.func_77973_b() == handler.getStackInSlot(i).func_77973_b()) {
              slot = i;
              break;
            }
          }
        if (slot != -1)
          Utils.setSelectedSlot(bag, slot);
      }
    }


    public static ItemStack onPickBlock(RayTraceResult target, EntityPlayer player, World world) {
      ItemStack result = ItemStack.field_190927_a;
      //boolean isCreative = player.capabilities.isCreativeMode;

      if (target.field_72313_a == RayTraceResult.Type.BLOCK) {
        BlockPos pos = target.func_178782_a();
        IBlockState state = world.func_180495_p(pos);

        if (state.func_177230_c().isAir(state, world, pos))
          return ItemStack.field_190927_a;

        //  if (isCreative && Screen.hasControlDown() && state.hasTileEntity())

        result = state.func_177230_c().getPickBlock(state, target, world, pos, player);

        if (result.func_190926_b())
          DankStorage.LOGGER.warn("Picking on: [{}] {} gave null item", target.hitInfo, state.func_177230_c().getRegistryName());
      }
      return result;
    }
  }
}
