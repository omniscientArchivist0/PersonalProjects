package com.tfar.dankstorage.screen;

import com.tfar.dankstorage.container.AbstractPortableDankContainer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

public abstract class AbstractPortableDankStorageScreen<T extends AbstractPortableDankContainer> extends AbstractAbstractDankStorageScreen<T> {

  protected ItemStack bag;

  public AbstractPortableDankStorageScreen(T container, InventoryPlayer playerinventory, ResourceLocation background) {
    super(container,playerinventory, background,container.rows);
    this.bag = playerinventory.field_70458_d.func_184614_ca();
  }

  @Override
  protected void func_146979_b(int mouseX, int mouseY) {
    super.func_146979_b(mouseX,mouseY);
    this.field_146289_q.func_78276_b(this.bag.func_82833_r(), 8, 7, 0x404040);
  }
}