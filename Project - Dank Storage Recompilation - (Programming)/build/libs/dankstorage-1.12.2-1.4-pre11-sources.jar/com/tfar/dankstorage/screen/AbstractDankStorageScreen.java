package com.tfar.dankstorage.screen;

import com.tfar.dankstorage.container.AbstractDankContainer;
import com.tfar.dankstorage.tile.AbstractDankStorageTile;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;

public abstract class AbstractDankStorageScreen<T extends AbstractDankContainer> extends AbstractAbstractDankStorageScreen<T> {

  protected AbstractDankStorageTile te;

  public AbstractDankStorageScreen(T container, InventoryPlayer playerinventory, ResourceLocation background) {
    super(container,playerinventory,background,container.rows);
    this.te = container.te;
  }

  @Override
  protected void func_146979_b(int mouseX, int mouseY) {
    super.func_146979_b(mouseX,mouseY);
    this.field_146289_q.func_78276_b(this.te.func_145748_c_().func_150261_e(), 8, 7, 4210752);
  }
}