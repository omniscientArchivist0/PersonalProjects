package com.tfar.dankstorage.recipe;

import com.google.gson.JsonObject;
import com.tfar.dankstorage.DankStorage;
import com.tfar.dankstorage.inventory.PortableDankHandler;
import com.tfar.dankstorage.util.Utils;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.crafting.CraftingHelper;
import net.minecraftforge.common.crafting.IRecipeFactory;
import net.minecraftforge.common.crafting.JsonContext;
import net.minecraftforge.oredict.ShapedOreRecipe;

import javax.annotation.Nonnull;

public class DankUpgradeRecipeFactory implements IRecipeFactory {

  @Override
  public IRecipe parse(JsonContext context, JsonObject json) {
    ShapedOreRecipe recipe = ShapedOreRecipe.factory(context, json);

    CraftingHelper.ShapedPrimer primer = new CraftingHelper.ShapedPrimer();
    primer.width = recipe.getRecipeWidth();
    primer.height = recipe.getRecipeHeight();
    primer.mirrored = JsonUtils.func_151209_a(json, "mirrored", true);
    primer.input = recipe.func_192400_c();

    return new DankRecipe(new ResourceLocation(DankStorage.MODID, "upgrade"), recipe.func_77571_b(), primer);  }


  public static class DankRecipe extends ShapedOreRecipe {
    public DankRecipe(ResourceLocation group, ItemStack result, CraftingHelper.ShapedPrimer primer) {
      super(group, result, primer);
    }

    @Override
    @Nonnull
    public ItemStack func_77572_b(@Nonnull InventoryCrafting inv) {

      ItemStack bag = super.func_77572_b(inv).func_77946_l();
      ItemStack oldBag = inv.func_70301_a(4);
      PortableDankHandler oldHandler = Utils.getHandler(oldBag);
      PortableDankHandler newHandler = Utils.getHandler(bag);
      for (int i = 0; i < oldHandler.getSlots(); i++) {
        newHandler.insertItem(i, oldHandler.getStackInSlot(i), false);
      }
      NBTTagCompound nbt = newHandler.serializeNBT();
      bag.func_77982_d(nbt);
      return bag;
    }
  }
}
