package com.tfar.dankstorage.client;

import net.minecraft.client.renderer.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;

import javax.annotation.Nullable;
import java.text.DecimalFormat;

public class RenderItemExtended {

  RenderItem itemRender = Minecraft.func_71410_x().func_175599_af();
  public static final RenderItemExtended INSTANCE = new RenderItemExtended();

  public void setZLevel(float z) {
    itemRender.field_77023_b = z;
  }

  public void renderItemOverlayIntoGUI(FontRenderer fr, ItemStack stack, int xPosition, int yPosition,
                                       @Nullable String text) {
    if (!stack.func_190926_b()) {

      if (stack.func_77973_b().showDurabilityBar(stack)) {
        GlStateManager.func_179140_f();
        GlStateManager.func_179097_i();
        GlStateManager.func_179090_x();
        GlStateManager.func_179118_c();
        GlStateManager.func_179084_k();
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder vertexbuffer = tessellator.func_178180_c();
        double health = stack.func_77973_b().getDurabilityForDisplay(stack);
        int rgbfordisplay = stack.func_77973_b().getRGBDurabilityForDisplay(stack);
        int i = Math.round(13.0F - (float) health * 13.0F);
        this.draw(vertexbuffer, xPosition + 2, yPosition + 13, 13, 2, 0, 0, 0, 255);
        this.draw(vertexbuffer, xPosition + 2, yPosition + 13, i, 1, rgbfordisplay >> 16 & 255, rgbfordisplay >> 8 & 255, rgbfordisplay & 255, 255);
        GlStateManager.func_179147_l();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
        GlStateManager.func_179145_e();
        GlStateManager.func_179126_j();
      }

      if (stack.func_190916_E() != 1 || text != null) {
        String s = text == null ? getStringFromInt(stack.func_190916_E()) : text;
        GlStateManager.func_179140_f();
        GlStateManager.func_179097_i();
        GlStateManager.func_179084_k();
        GlStateManager.func_179094_E();
        float scale = .75f;
        GlStateManager.func_179152_a(scale, scale, 1.0F);
        fr.func_175063_a(s, (xPosition + 19 - 2 - (fr.func_78256_a(s)*scale)) /scale,
                (yPosition + 6 + 3 + (1 / (scale * scale) - 1) ) /scale, 0xffffff);
        GlStateManager.func_179121_F();
        GlStateManager.func_179145_e();
        GlStateManager.func_179126_j();
        // Fixes opaque cooldown overlay a bit lower
        // TODO: check if enabled blending still screws things up down
        // the line.
        GlStateManager.func_179147_l();
      }

      EntityPlayerSP entityplayersp = Minecraft.func_71410_x().field_71439_g;
      float f3 = entityplayersp == null ? 0.0F
              : entityplayersp.func_184811_cZ().func_185143_a(stack.func_77973_b(),
              Minecraft.func_71410_x().func_184121_ak());

      if (f3 > 0.0F) {
        GlStateManager.func_179140_f();
        GlStateManager.func_179097_i();
        GlStateManager.func_179090_x();
        Tessellator tessellator1 = Tessellator.func_178181_a();
        BufferBuilder vertexbuffer1 = tessellator1.func_178180_c();
        this.draw(vertexbuffer1, xPosition, yPosition + MathHelper.func_76141_d(16.0F * (1.0F - f3)), 16,
                MathHelper.func_76123_f(16.0F * f3), 255, 255, 255, 127);
        GlStateManager.func_179098_w();
        GlStateManager.func_179145_e();
        GlStateManager.func_179126_j();
      }
    }
  }

  private static final DecimalFormat decimalFormat = new DecimalFormat("0.#");

  public String getStringFromInt(int number){

    if (number >= 1000000000) return decimalFormat.format(number / 1000000000f) + "b";
    if (number >= 1000000) return decimalFormat.format(number / 1000000f) + "m";
    if (number >= 1000) return decimalFormat.format(number / 1000f) + "k";

    return Float.toString(number).replaceAll("\\.?0*$", "");
  }

  private void draw(BufferBuilder renderer, int x, int y, int width, int height, int red, int green, int blue,
                    int alpha) {
    renderer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
    renderer.func_181662_b(x, y, 0.0D).func_181669_b(red, green, blue, alpha).func_181675_d();
    renderer.func_181662_b(x, y + height, 0.0D).func_181669_b(red, green, blue, alpha).func_181675_d();
    renderer.func_181662_b(x + width, y + height, 0.0D).func_181669_b(red, green, blue, alpha).func_181675_d();
    renderer.func_181662_b(x + width, y, 0.0D).func_181669_b(red, green, blue, alpha).func_181675_d();
    Tessellator.func_178181_a().func_78381_a();
  }
}