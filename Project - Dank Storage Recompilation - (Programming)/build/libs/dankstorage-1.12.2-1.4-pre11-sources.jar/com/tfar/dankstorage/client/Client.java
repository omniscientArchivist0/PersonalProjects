package com.tfar.dankstorage.client;

import com.tfar.dankstorage.DankStorage;
import com.tfar.dankstorage.block.DankItemBlock;
import com.tfar.dankstorage.inventory.PortableDankHandler;
import com.tfar.dankstorage.network.*;
import com.tfar.dankstorage.network.CMessageToggle.KeybindToggleType;
import com.tfar.dankstorage.util.Utils;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ContainerPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.relauncher.Side;
import org.lwjgl.input.Keyboard;


@Mod.EventBusSubscriber(value = Side.CLIENT)
public class Client {

  public static KeyBinding AUTO_PICKUP;
  public static KeyBinding AUTO_VOID;
  public static KeyBinding CONSTRUCTION;
  private static final Minecraft mc = Minecraft.func_71410_x();

  @SubscribeEvent
  public static void client(ModelRegistryEvent e) {

    AUTO_PICKUP = new KeyBinding("key.dankstorage.pickup", Keyboard.KEY_P, "key.categories.dankstorage");
    AUTO_VOID = new KeyBinding("key.dankstorage.void", Keyboard.KEY_O, "key.categories.dankstorage");
    CONSTRUCTION = new KeyBinding("key.dankstorage.construction", Keyboard.KEY_I, "key.categories.dankstorage");

    ClientRegistry.registerKeyBinding(AUTO_PICKUP);
    ClientRegistry.registerKeyBinding(AUTO_VOID);
    ClientRegistry.registerKeyBinding(CONSTRUCTION);
    for (Block block : DankStorage.RegistryEvents.MOD_BLOCKS)
      registerModelLocation(Item.func_150898_a(block));
  }

  private static void registerModelLocation(Item item) {
    ModelLoader.setCustomModelResourceLocation(item, 0, new ModelResourceLocation(item.getRegistryName(), "inventory"));
  }

  @Mod.EventBusSubscriber(value = Side.CLIENT)
  public static class KeyHandler {
    @SubscribeEvent
    public static void onKeyInput(InputEvent.KeyInputEvent event) {
      if (mc.field_71439_g == null || !(mc.field_71439_g.func_184614_ca().func_77973_b() instanceof DankItemBlock
              || mc.field_71439_g.func_184592_cb().func_77973_b() instanceof DankItemBlock)) return;
      if (AUTO_PICKUP.func_151468_f()) {
        DankPacketHandler.INSTANCE.sendToServer(new CMessageToggle(KeybindToggleType.PICKUP));
      }
      if (AUTO_VOID.func_151468_f()) {
        DankPacketHandler.INSTANCE.sendToServer(new CMessageToggle(KeybindToggleType.VOID));
      }
      if (CONSTRUCTION.func_151468_f()) {
        DankPacketHandler.INSTANCE.sendToServer(new CMessageToggle(KeybindToggleType.CONSTRUCTION));
      }
      if (mc.field_71474_y.field_74322_I.func_151468_f()) {
        DankPacketHandler.INSTANCE.sendToServer(new CMessagePickBlock());
      }
    }
  }

    @SubscribeEvent
    public static void mousewheel(MouseEvent e) {
      EntityPlayer player = mc.field_71439_g;
      if ((Utils.construction(player.func_184614_ca()) || Utils.construction(player.func_184614_ca())) && player.func_70093_af() && e.getDwheel() != 0) {
        boolean right = e.getDwheel() < 0;
        DankPacketHandler.INSTANCE.sendToServer(new CMessageChangeSlot(right));
        e.setCanceled(true);
      }
    }

    @SubscribeEvent
    public static void onRenderTick(RenderGameOverlayEvent.Post event) {
      EntityPlayer player = mc.field_71439_g;
      if (player == null) return;
      if (!(player.field_71070_bA instanceof ContainerPlayer)) return;
      ItemStack bag = player.func_184614_ca();
      if (!(bag.func_77973_b() instanceof DankItemBlock)) {
        bag = player.func_184592_cb();
        if (!(bag.func_77973_b() instanceof DankItemBlock))return;
      }
      int x = event.getResolution().func_78326_a()/2;
      int y = event.getResolution().func_78328_b();
      PortableDankHandler handler = Utils.getHandler(bag);
      ItemStack toPlace = handler.getStackInSlot(Utils.getSelectedSlot(bag));
      String s = toPlace.func_82833_r();
      // String s1 = s.getUnformattedComponentText();
      //String slot = String.valueOf(Utils.getSelectedSlot(bag));

      int count = toPlace.func_190916_E();

      if (!toPlace.func_190926_b()) {
        GlStateManager.func_179091_B();
        RenderHelper.func_74520_c();
        int itemX = x - 140;
        int itemY = y - 20;
        float pickupAnimation = toPlace.func_190921_D() - 1;
        if (pickupAnimation > 0.0F) {
          GlStateManager.func_179094_E();
          float scale = 1 + pickupAnimation / 5;
          GlStateManager.func_179109_b(itemX + 8, itemY + 12, 0);
          GlStateManager.func_179152_a(1 / scale, scale + 1 / 2f, 1);
          GlStateManager.func_179109_b(-(itemX + 8), -(itemY + 12), 0);
        }
        mc.func_175599_af().func_180450_b(toPlace, itemX, itemY);
        mc.func_175599_af().func_180453_a(mc.field_71466_p,toPlace, itemX, itemY,null);
        if (pickupAnimation > 0.0F)
          mc.func_175599_af().func_175030_a(mc.field_71466_p, toPlace, itemX, itemY);
        RenderHelper.func_74518_a();
        GlStateManager.func_179101_C();

        mc.func_110434_K().func_110577_a(Gui.field_110324_m);

        //GlStateManager.popMatrix();
      }
    }

    private static FontRenderer fontRenderer;

    public static void drawLineOffsetStringOnHUD(String string, int xOffset, int yOffset, int color, int lineOffset) {
      drawStringOnHUD(string, xOffset, yOffset, color, lineOffset);
    }

    public static void drawStringOnHUD(String string, int xOffset, int yOffset, int color, int lineOffset) {
      yOffset += lineOffset * 9;
      if (fontRenderer == null) fontRenderer = mc.field_71466_p;
      fontRenderer.func_78276_b(string, 2 + xOffset, 2 + yOffset, color);
    }
  }
