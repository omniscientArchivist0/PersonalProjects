package com.tfar.dankstorage.block;

import com.tfar.dankstorage.DankStorage;
import com.tfar.dankstorage.capability.CapabilityDankStorageProvider;
import com.tfar.dankstorage.inventory.PortableDankHandler;
import com.tfar.dankstorage.util.DankConstants;
import com.tfar.dankstorage.util.Utils;
import net.minecraft.block.Block;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.common.capabilities.ICapabilityProvider;

import javax.annotation.Nonnull;

public class DankItemBlock extends ItemBlock {
  public DankItemBlock(Block p_i48527_1_) {
    super(p_i48527_1_);
  }

  @Override
  public ICapabilityProvider initCapabilities(final ItemStack stack, final NBTTagCompound nbt) {
    return new CapabilityDankStorageProvider(stack);
  }

  @Nonnull
  @Override
  public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer player, EnumHand hand) {
      if (!world.field_72995_K && player.func_70093_af()) {
        if (player.func_184586_b(hand).func_77973_b() instanceof DankItemBlock) {
          player.openGui(DankStorage.instance, DankConstants.BAG_GUI_ID, world, 0, 0, 0);
        }
      } else {
        ItemStack bag = player.func_184586_b(hand);
        PortableDankHandler handler = Utils.getHandler(bag);
        ItemStack toPlace = handler.getStackInSlot(Utils.getSelectedSlot(bag));
        EntityEquipmentSlot hand1 = hand == EnumHand.MAIN_HAND ? EntityEquipmentSlot.MAINHAND : EntityEquipmentSlot.OFFHAND;
        if (isSuperStacked(toPlace)){
          ItemStack unStack = toPlace.func_77946_l();
          handler.extractItem(Utils.getSelectedSlot(bag),1,false);
          handler.writeItemStack();
          unStack.func_190920_e(1);
          player.func_184201_a(hand1, unStack);
          ActionResult<ItemStack> actionResult = unStack.func_77973_b().func_77659_a(world, player, hand);
          ItemStack result = actionResult.func_188398_b();
          for (int i = 0; i < handler.getSlots();i++) {
            ItemStack stack2 = handler.insertItem(i, result, false);
            if (stack2.func_190926_b())break;
          }
          handler.writeItemStack();
          player.func_184201_a(hand1, bag);
          return super.func_77659_a(world, player, hand);
        }


        player.func_184201_a(hand1, toPlace);
        ActionResult<ItemStack> actionResult = toPlace.func_77973_b().func_77659_a(world, player, hand);
        handler.setStackInSlot(Utils.getSelectedSlot(bag), actionResult.func_188398_b());
        player.func_184201_a(hand1, bag);
      }
    return super.func_77659_a(world, player, hand);
  }

  public boolean isSuperStacked(ItemStack stack){
    return stack.func_77976_d() == 1 && stack.func_190916_E() > 1;
  }

  @Override
  public boolean func_111207_a(ItemStack bag, EntityPlayer player, EntityLivingBase entity, EnumHand hand) {
    if (!Utils.construction(bag))return false;
    PortableDankHandler handler = Utils.getHandler(bag);
    ItemStack toPlace = handler.getStackInSlot(Utils.getSelectedSlot(bag));
    EntityEquipmentSlot hand1 = hand == EnumHand.MAIN_HAND ? EntityEquipmentSlot.MAINHAND : EntityEquipmentSlot.OFFHAND;
    player.func_184201_a(hand1, toPlace);
    boolean result = toPlace.func_77973_b().func_111207_a(toPlace, player, entity, hand);
    handler.setStackInSlot(Utils.getSelectedSlot(bag),toPlace);
    player.func_184201_a(hand1, bag);
    return result;
  }

  @Override
  public boolean func_77636_d(ItemStack stack) {
    return stack.func_77942_o() && Utils.construction(stack);
  }

  @Nonnull
  @Override
  public EnumActionResult func_180614_a(EntityPlayer player, World world, BlockPos pos, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
    ItemStack bag = player.func_184586_b(hand);
    if (!Utils.construction(bag))
      return super.func_180614_a(player, world, pos, hand, facing, hitX, hitY, hitZ);

    PortableDankHandler handler = Utils.getHandler(bag);
    int selectedSlot = Utils.getSelectedSlot(bag);
    ItemStack usedStack = handler.getStackInSlot(selectedSlot);
    EntityEquipmentSlot hand1 = hand == EnumHand.MAIN_HAND ? EntityEquipmentSlot.MAINHAND : EntityEquipmentSlot.OFFHAND;
    if (isSuperStacked(usedStack)) {
      handler.extractItem(Utils.getSelectedSlot(bag),1,false);
      handler.writeItemStack();
      ItemStack unStack = usedStack.func_77946_l();
      unStack.func_190920_e(1);
      player.func_184201_a(hand1,unStack);
      EnumActionResult actionResultType = unStack.func_77973_b().func_180614_a(player,world,pos,hand,facing,hitX,hitY,hitZ);
      for (int i = 0; i < handler.getSlots();i++) {
        ItemStack stack2 = handler.insertItem(i, unStack, false);
        if (stack2.func_190926_b())break;
      }
      handler.writeItemStack();
      player.func_184201_a(hand1,bag);
      return actionResultType;
    }

    player.func_184201_a(hand1,usedStack);
    EnumActionResult actionResultType = usedStack.func_77973_b().func_180614_a(player,world,pos,hand,facing,hitX,hitY,hitZ);
    handler.setStackInSlot(selectedSlot, usedStack);
    player.func_184201_a(hand1,bag);
    return actionResultType;
  }
}
