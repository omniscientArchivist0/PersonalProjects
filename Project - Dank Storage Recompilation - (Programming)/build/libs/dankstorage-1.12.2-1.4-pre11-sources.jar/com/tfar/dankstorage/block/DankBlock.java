package com.tfar.dankstorage.block;

import com.tfar.dankstorage.DankStorage;
import com.tfar.dankstorage.client.Client;
import com.tfar.dankstorage.inventory.DankHandler;
import com.tfar.dankstorage.inventory.PortableDankHandler;
import com.tfar.dankstorage.util.DankConstants;
import com.tfar.dankstorage.util.Utils;
import com.tfar.dankstorage.tile.AbstractDankStorageTile;
import com.tfar.dankstorage.tile.DankTiles;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.*;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Random;

public class DankBlock extends Block {
  public DankBlock(Material p_i48440_1_) {
    super(p_i48440_1_);
  }


  @Override
  public boolean func_180639_a(World world, BlockPos pos, IBlockState state, EntityPlayer player, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
    if (!world.field_72995_K) {
      TileEntity tileEntity = world.func_175625_s(pos);
      if (tileEntity instanceof AbstractDankStorageTile) {
      player.openGui(DankStorage.instance, DankConstants.TILE_GUI_ID, world, pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
      }
    }
    return true;
  }

  @Override
  public Item func_180660_a(IBlockState state, Random rand, int fortune) {
    return Items.field_190931_a;
  }

  @Override
  public void func_176208_a(World world, BlockPos pos, IBlockState state, EntityPlayer player) {
    final TileEntity tile = world.func_175625_s(pos);
    if (tile instanceof AbstractDankStorageTile && !world.field_72995_K){
      ItemStack dank = new ItemStack(((AbstractDankStorageTile) tile).getDank());
      NBTTagCompound nbt = ((AbstractDankStorageTile) tile).itemHandler.serializeNBT();
      nbt.func_74757_a("pickup",((AbstractDankStorageTile) tile).pickup);
      nbt.func_74757_a("void",((AbstractDankStorageTile) tile).isVoid);
      nbt.func_74768_a("selectedSlot",((AbstractDankStorageTile) tile).selectedSlot);
      dank.func_77982_d(nbt);
      EntityItem itemEntity = new EntityItem(world,pos.func_177958_n()+ .5,pos.func_177956_o() + .5,pos.func_177952_p()+.5,dank);
      world.func_72838_d(itemEntity);
    }
  }

  @Override
  public void func_180633_a(World world, BlockPos pos, IBlockState state, @Nullable EntityLivingBase entity, ItemStack stack) {
    TileEntity te = world.func_175625_s(pos);
    if (te instanceof AbstractDankStorageTile && !world.field_72995_K && entity != null) {
      if (stack.func_77942_o()){
        ((AbstractDankStorageTile) te).setContents(stack.func_77978_p());
        ((AbstractDankStorageTile) te).pickup = stack.func_77978_p().func_74767_n("pickup");
        ((AbstractDankStorageTile) te).isVoid = stack.func_77978_p().func_74767_n("void");
        ((AbstractDankStorageTile) te).selectedSlot = stack.func_77978_p().func_74762_e("selectedSlot");
      }
    }
  }


  @Override
  public IBlockState getStateForPlacement(World world, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer, EnumHand hand) {
    ItemStack bag = placer.func_184586_b(hand);
    if (!Utils.construction(bag))
    return super.getStateForPlacement(world, pos, facing, hitX, hitY, hitZ, meta, placer, hand);

    Block block = Block.func_149634_a(bag.func_77973_b());
    if (block instanceof DankBlock)return block.func_176223_P();
    return block.isAir(block.func_176223_P(),null,null) ? null : block.getStateForPlacement(world,pos,facing,hitX,hitY,hitZ,meta,placer,hand);
  }

  @Override
  public boolean hasTileEntity(IBlockState state) {
    return true;
  }

  @Nullable
  @Override
  public TileEntity createTileEntity(World world, IBlockState state) {
    int type = Utils.getTier(this.getRegistryName());
    switch (type) {
      case 1:
      default:
        return new DankTiles.DankStorageTile1();
      case 2:
        return new DankTiles.DankStorageTile2();
      case 3:
        return new DankTiles.DankStorageTile3();
      case 4:
        return new DankTiles.DankStorageTile4();
      case 5:
        return new DankTiles.DankStorageTile5();
      case 6:
        return new DankTiles.DankStorageTile6();
      case 7:
        return new DankTiles.DankStorageTile7();
    }
  }




  @Override
  @SideOnly(Side.CLIENT)
  public void func_190948_a(ItemStack bag, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
    //if (bag.hasTag())tooltip.add(new StringTextComponent(bag.getTagCompound().toString()));

    if (!GuiScreen.func_146272_n()){
      tooltip.add(I18n.func_135052_a("text.dankstorage.shift", Minecraft.func_71410_x().field_71474_y.field_74311_E.getDisplayName()));
    }

    if (GuiScreen.func_146272_n()) {
      if (Utils.autoVoid(bag)) tooltip.add(I18n.func_135052_a("text.dankstorage.disablevoid", Client.AUTO_VOID.getDisplayName()));
              else tooltip.add(I18n.func_135052_a("text.dankstorage.enablevoid", Client.AUTO_VOID.getDisplayName()));
      if (Utils.autoPickup(bag)) tooltip.add(
              I18n.func_135052_a("text.dankstorage.disablepickup", Client.AUTO_PICKUP.getDisplayName()));
      else tooltip.add(
              I18n.func_135052_a("text.dankstorage.enablepickup", Client.AUTO_PICKUP.getDisplayName()));
      DankHandler handler = Utils.getHandler(bag);

      if (handler.isEmpty()){
        tooltip.add(I18n.func_135052_a("text.dankstorage.empty"));
        return;
      }

      for (int i = 0; i < handler.getSlots(); i++) {
        ItemStack item = handler.getStackInSlot(i);
        if (item.func_190926_b())continue;
          String count = Integer.toString(item.func_190916_E());
        tooltip.add(I18n.func_135052_a("text.dankstorage.formatcontaineditems",TextFormatting.AQUA+count,item.func_77973_b().getForgeRarity(item).getColor()+item.func_82833_r()));


      }
    }
  }

  public static boolean onItemPickup(EntityItemPickupEvent event, ItemStack bag) {

    if (!bag.func_77942_o() || !bag.func_77978_p().func_74767_n("pickup")) {
      return false;
    }
    ItemStack toPickup = event.getItem().func_92059_d();
    final boolean isVoid = Utils.autoVoid(bag);

    if (true) {
      if (false) {
     //   toPickup.setCount(0);
     //   bag.setAnimationsToGo(5);
    //    PlayerEntity player = event.getEntityPlayer();
      //  player.world.playSound(null, player.posX, player.posY, player.posZ, SoundEvents.ENTITY_ITEM_PICKUP, SoundCategory.PLAYERS, 0.2F, (MathHelper.RANDOM.nextFloat() - MathHelper.RANDOM.nextFloat()) * 0.7F + 1.0F);
        return true;
        //todo watch for dupes
      } else if (true) {
        int count = toPickup.func_190916_E();
        PortableDankHandler inv = Utils.getHandler(bag);
        for (int i = 0; i < inv.getSlots(); i++) {
          ItemStack stackInSlot = inv.getStackInSlot(i);
          if (stackInSlot.func_190926_b()  && !isVoid) {
            inv.setStackInSlot(i, toPickup.func_77946_l());
            toPickup.func_190920_e(toPickup.func_190916_E() - inv.getStackLimit(i,toPickup));
          } else if (canAddItemToSlot(inv,stackInSlot, toPickup,true)) {
            int fill = inv.stacklimit - stackInSlot.func_190916_E();
            if (fill > toPickup.func_190916_E()) {
              stackInSlot.func_190920_e(stackInSlot.func_190916_E() + toPickup.func_190916_E());
            } else {
              stackInSlot.func_190920_e(inv.stacklimit);
            }
            if (!isVoid)
            toPickup.func_77979_a(fill);
            else if (toPickup.func_77969_a(stackInSlot) && ItemStack.func_77970_a(stackInSlot, toPickup))
              toPickup.func_190920_e(0);
          }
          if (toPickup.func_190926_b()) {
            break;
          }
        }
        if (toPickup.func_190916_E() != count) {
          bag.func_190915_d(5);
          EntityPlayer player = event.getEntityPlayer();
          player.field_70170_p.func_184148_a(null, player.field_70165_t, player.field_70163_u, player.field_70161_v, SoundEvents.field_187638_cR, SoundCategory.PLAYERS, 0.2F, ((player.func_70681_au().nextFloat() - player.func_70681_au().nextFloat()) * 0.7F + 1.0F) * 2.0F);
          inv.writeItemStack();
        }
      }
    }
    return toPickup.func_190926_b();
  }

  public static boolean canAddItemToSlot(PortableDankHandler handler, ItemStack stackInSlot, ItemStack pickup, boolean stackSizeMatters) {
    boolean isEmpty = stackInSlot.func_190926_b();

    if (!isEmpty && pickup.func_77969_a(stackInSlot) && ItemStack.func_77970_a(stackInSlot, pickup)) {
      return stackInSlot.func_190916_E() + (stackSizeMatters ? 0 : pickup.func_190916_E()) <= handler.stacklimit;
    }

    return isEmpty;
  }
}
