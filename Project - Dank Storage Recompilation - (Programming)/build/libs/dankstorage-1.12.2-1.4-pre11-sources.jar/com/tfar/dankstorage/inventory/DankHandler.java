package com.tfar.dankstorage.inventory;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.common.util.Constants;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.items.ItemStackHandler;

import javax.annotation.Nonnull;
import java.util.stream.IntStream;

public class DankHandler extends ItemStackHandler {

  public final int stacklimit;

  public DankHandler(int size, int stacklimit) {
    super(size);
    this.stacklimit = stacklimit;
  }

  public boolean isEmpty(){
    return IntStream.range(0, this.getSlots()).allMatch(i -> this.getStackInSlot(i).func_190926_b());
  }

  @Override
  public int getSlotLimit(int slot) {
    return stacklimit;
  }

  @Override
  public int getStackLimit(int slot, @Nonnull ItemStack stack) {
    return stacklimit;
  }

  @Override
  public void onContentsChanged(int slot) {

  }

  @Override
  @Nonnull
  public ItemStack extractItem(int slot, int amount, boolean simulate) {
    if (amount == 0)
      return ItemStack.field_190927_a;

    validateSlotIndex(slot);

    ItemStack existing = this.stacks.get(slot);

    if (existing.func_190926_b())
      return ItemStack.field_190927_a;

    int toExtract = Math.min(amount, stacklimit);

    if (existing.func_77976_d() == 1)toExtract = 1;

    if (existing.func_190916_E() <= toExtract) {
      if (!simulate) {
        this.stacks.set(slot, ItemStack.field_190927_a);
        onContentsChanged(slot);
      }
      return existing;
    } else {
      if (!simulate) {
        this.stacks.set(slot, ItemHandlerHelper.copyStackWithSize(existing, existing.func_190916_E() - toExtract));
        onContentsChanged(slot);
      }

      return ItemHandlerHelper.copyStackWithSize(existing, toExtract);
    }
  }

  public NonNullList<ItemStack> getContents(){
    return stacks;
  }

  @Override
  public NBTTagCompound serializeNBT() {
    NBTTagList nbtTagList = new NBTTagList();
    for (int i = 0; i < stacks.size(); i++) {
      if (!stacks.get(i).func_190926_b()) {
        int realCount = Math.min(stacklimit, stacks.get(i).func_190916_E());
        NBTTagCompound itemTag = new NBTTagCompound();
        itemTag.func_74768_a("Slot", i);
        stacks.get(i).func_77955_b(itemTag);
        itemTag.func_74768_a("ExtendedCount", realCount);
        nbtTagList.func_74742_a(itemTag);
      }
    }
    NBTTagCompound nbt = new NBTTagCompound();
    nbt.func_74782_a("Items", nbtTagList);
    nbt.func_74768_a("Size", stacks.size());
    return nbt;
  }

  @Override
  public void deserializeNBT(NBTTagCompound nbt) {
    setSize(nbt.func_150297_b("Size", Constants.NBT.TAG_INT) ? nbt.func_74762_e("Size") : stacks.size());
    NBTTagList tagList = nbt.func_150295_c("Items", Constants.NBT.TAG_COMPOUND);
    for (int i = 0; i < tagList.func_74745_c(); i++) {
      NBTTagCompound itemTags = tagList.func_150305_b(i);
      int slot = itemTags.func_74762_e("Slot");

      if (slot >= 0 && slot < stacks.size()) {
        if (itemTags.func_150297_b("StackList", Constants.NBT.TAG_LIST)) { // migrate from old ExtendedItemStack system
          ItemStack stack = ItemStack.field_190927_a;
          NBTTagList stackTagList = itemTags.func_150295_c("StackList", Constants.NBT.TAG_COMPOUND);
          for (int j = 0; j < stackTagList.func_74745_c(); j++) {
            NBTTagCompound itemTag = stackTagList.func_150305_b(j);
            ItemStack temp = new ItemStack(itemTag);
            if (!temp.func_190926_b()) {
              if (stack.func_190926_b()) stack = temp;
              else stack.func_190917_f(temp.func_190916_E());
            }
          }
          if (!stack.func_190926_b()) {
            int count = stack.func_190916_E();
            count = Math.min(count, getStackLimit(slot, stack));
            stack.func_190920_e(count);

            stacks.set(slot, stack);
          }
        } else {
          ItemStack stack = new ItemStack(itemTags);
          if (itemTags.func_150297_b("ExtendedCount", Constants.NBT.TAG_INT)) {
            stack.func_190920_e(itemTags.func_74762_e("ExtendedCount"));
          }
          stacks.set(slot, stack);
        }
      }
    }
    onLoad();
  }

  public int calcRedstone() {
    int numStacks = 0;
    float f = 0F;

    for (int slot = 0; slot < this.getSlots(); slot++) {
      ItemStack stack = this.getStackInSlot(slot);

      if (!stack.func_190926_b()) {
        f += (float) stack.func_190916_E() / (float) this.getStackLimit(slot, stack);
        numStacks++;
      }
    }

    f /= this.getSlots();
    return MathHelper.func_76141_d(f * 14F) + (numStacks > 0 ? 1 : 0);
  }
}
