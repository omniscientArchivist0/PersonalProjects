package com.tfar.dankstorage.inventory;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

import javax.annotation.Nonnull;

public class DankSlot extends Slot {
  private static IInventory emptyInventory = new InventoryBasic("empty",false,0);
  private final DankHandler itemHandler;
  private final int index;

  public DankSlot(DankHandler itemHandler, int index, int xPosition, int yPosition) {
    super(emptyInventory, index, xPosition, yPosition);
    this.itemHandler = itemHandler;
    this.index = index;
  }

  @Override
  public boolean func_75214_a(@Nonnull ItemStack stack) {
    if (stack.func_190926_b()) return false;

    ItemStack currentStack = getItemHandler().getStackInSlot(index);

    getItemHandler().setStackInSlot(index, ItemStack.field_190927_a);

    ItemStack remainder = getItemHandler().insertItem(index, stack, true);

    getItemHandler().setStackInSlot(index, currentStack);

    return remainder.func_190926_b() || remainder.func_190916_E() < stack.func_190916_E();
  }

  @Override
  @Nonnull
  public ItemStack func_75211_c() {
    return this.getItemHandler().getStackInSlot(index);
  }

  @Override
  public void func_75215_d(@Nonnull ItemStack stack) {
    this.getItemHandler().setStackInSlot(index, stack);
    this.func_75218_e();
  }

  @Override
  public void func_75220_a(@Nonnull ItemStack p_75220_1_, @Nonnull ItemStack p_75220_2_) {
    getItemHandler().onContentsChanged(index);
  }

  @Override
  public int func_75219_a() {
    return this.itemHandler.getSlotLimit(this.index);
  }

  @Override
  public int func_178170_b(@Nonnull ItemStack stack) {
    return this.itemHandler.getStackLimit(this.index, stack);
  }

  @Override
  public boolean func_82869_a(EntityPlayer playerIn) {
    return !this.getItemHandler().extractItem(index, 1, true).func_190926_b();
  }

  @Override
  @Nonnull
  public ItemStack func_75209_a(int amount) {
    return this.getItemHandler().extractItem(index, amount, false);
  }

  public DankHandler getItemHandler() {
    return itemHandler;
  }

  @Override
  public boolean isSameInventory(Slot other) {
    return other instanceof DankSlot && ((DankSlot) other).getItemHandler() == this.itemHandler;
  }
}
