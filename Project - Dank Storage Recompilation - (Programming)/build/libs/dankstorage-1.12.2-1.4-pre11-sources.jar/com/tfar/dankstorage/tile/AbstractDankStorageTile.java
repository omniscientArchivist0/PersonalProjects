package com.tfar.dankstorage.tile;

import com.tfar.dankstorage.block.DankBlock;
import com.tfar.dankstorage.inventory.DankHandler;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.items.CapabilityItemHandler;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public abstract class AbstractDankStorageTile extends TileEntity {

  public int numPlayersUsing = 0;
  protected String customName;
  public int renderTick = 0;
  public boolean pickup;
  public boolean isVoid;
  public int selectedSlot;

  public DankHandler itemHandler;

  public AbstractDankStorageTile(int rows, int stacksize) {
    this.itemHandler = new DankHandler(rows * 9,stacksize) {
      @Override
      public void onContentsChanged(int slot) {
        super.onContentsChanged(slot);
        AbstractDankStorageTile.this.field_145850_b.func_175641_c(AbstractDankStorageTile.this.field_174879_c, AbstractDankStorageTile.this.field_145854_h, 1, AbstractDankStorageTile.this.numPlayersUsing);
        AbstractDankStorageTile.this.func_70296_d();
      }
    };
  }

  public int getRenderTick() {
    return renderTick;
  }

  public int getComparatorSignal() {
    return this.itemHandler.calcRedstone();
  }

  /*@Override
  public void tick() {

  }*/

  @Nullable
  @Override
  public ITextComponent func_145748_c_() {
    return new TextComponentTranslation("container." + getDank().getRegistryName().toString());
  }

  @Override
  public boolean func_145842_c(int id, int type) {
    if (id == 1) {
      this.numPlayersUsing = type;
      this.func_70296_d();
      return true;
    } else {
      return super.func_145842_c(id, type);
    }
  }

  public void openInventory(EntityPlayer player) {
    if (!player.func_175149_v()) {
      if (this.numPlayersUsing < 0) {
        this.numPlayersUsing = 0;
      }

      ++this.numPlayersUsing;
      this.field_145850_b.func_175641_c(this.field_174879_c, this.field_145854_h, 1, this.numPlayersUsing);
      this.field_145850_b.func_175685_c(this.field_174879_c, field_145854_h,false);
      func_70296_d();
    }
  }

  public void closeInventory(EntityPlayer player) {
    if (!player.func_175149_v() && this.field_145854_h instanceof DankBlock) {
      --this.numPlayersUsing;
      this.field_145850_b.func_175641_c(this.field_174879_c, field_145854_h, 1, this.numPlayersUsing);
      this.field_145850_b.func_175685_c(this.field_174879_c, this.field_145854_h,false);
      func_70296_d();
    }
  }

  @Override
  public void func_145839_a(NBTTagCompound compound) {
    super.func_145839_a(compound);
    this.isVoid = compound.func_74767_n("void");
    this.pickup = compound.func_74767_n("pickup");
    this.selectedSlot = compound.func_74762_e("selectedSlot");
    if (compound.func_74764_b("Items")) {
      itemHandler.deserializeNBT(compound.func_74775_l("Items"));
    }
 //   if (compound.hasKey("CustomName", 8)) {
  //    this.setCustomName(compound.getString("CustomName"));
  //  }
  }

  @Override
  public NBTTagCompound func_189515_b(NBTTagCompound compound) {
    super.func_189515_b(compound);
    compound.func_74757_a("void", isVoid);
    compound.func_74757_a("pickup",pickup);
    compound.func_74768_a("selectedSlot",selectedSlot);
    compound.func_74782_a("Items", itemHandler.serializeNBT());
 //   if (this.hasCustomName()) {
 //     compound.putString("CustomName", this.customName);
 //   }
    return compound;
  }

  @Override
  public NBTTagCompound func_189517_E_() {
    return func_189515_b(new NBTTagCompound());
  }

  @Nullable
  @Override
  public SPacketUpdateTileEntity func_189518_D_() {
    return new SPacketUpdateTileEntity(func_174877_v(), 1, func_189517_E_());
  }

  @Override
  public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
    func_145839_a(pkt.func_148857_g());
  }

  @Override
  public void func_70296_d() {
    super.func_70296_d();
    if (func_145831_w() != null) {
      func_145831_w().func_184138_a(field_174879_c, func_145831_w().func_180495_p(field_174879_c), func_145831_w().func_180495_p(field_174879_c), 3);
      this.field_145850_b.func_175685_c(this.field_174879_c, field_145854_h,false);
    }
  }

  @Override
  public boolean hasCapability(Capability<?> capability, @Nullable EnumFacing facing) {
    return capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY || super.hasCapability(capability, facing);
  }

  @SuppressWarnings("unchecked")
  @Override
  public <T> T getCapability(@Nonnull Capability<T> capability, @Nullable EnumFacing facing) {
    return capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY ?  (T)itemHandler : super.getCapability(capability, facing);
  }

  public abstract Item getDank();

  public void setContents(NBTTagCompound nbt){
    itemHandler.deserializeNBT(nbt);
  }
}