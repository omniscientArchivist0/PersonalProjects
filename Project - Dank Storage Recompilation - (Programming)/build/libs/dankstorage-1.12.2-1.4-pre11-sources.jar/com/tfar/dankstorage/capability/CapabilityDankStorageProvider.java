package com.tfar.dankstorage.capability;

import com.tfar.dankstorage.inventory.PortableDankHandler;
import com.tfar.dankstorage.util.Utils;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.items.CapabilityItemHandler;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class CapabilityDankStorageProvider implements ICapabilityProvider {

  private PortableDankHandler handler;


  public CapabilityDankStorageProvider(ItemStack stack) {

    this.handler = new PortableDankHandler(stack) {
      @Override
      public void onContentsChanged(int slot) {
        super.onContentsChanged(slot);
        stack.func_77982_d((NBTTagCompound) CapabilityDankStorage.DANK_STORAGE_CAPABILITY.writeNBT(this, null));
      }
    };
    if (stack.func_77942_o())
      CapabilityDankStorage.DANK_STORAGE_CAPABILITY.readNBT(this.handler, null, stack.func_77978_p());
  }

  @Override
  public boolean hasCapability(@Nonnull Capability<?> cap, @Nullable EnumFacing facing) {
    return cap == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY;
  }

  /**
   * Retrieves the Optional handler for the capability requested on the specific side.
   * The return value <strong>CAN</strong> be the same for multiple faces.
   * Modders are encouraged to cache this value, using the listener capabilities of the Optional to
   * be notified if the requested capability get lost.
   *
   * @param cap
   * @param side
   * @return The requested an optional holding the requested capability.
   */
  @Nonnull
  @Override
  public <T> T getCapability(@Nonnull Capability<T> cap, @Nullable EnumFacing side) {
    if (cap == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY)
      return (T) handler;
    else return null;
  }
}
