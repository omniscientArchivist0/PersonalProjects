package com.tfar.dankstorage.capability;

import com.tfar.dankstorage.inventory.DankHandler;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityInject;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.util.Constants;

public class CapabilityDankStorage {
  @CapabilityInject(DankHandler.class)
  public static Capability<DankHandler> DANK_STORAGE_CAPABILITY = null;

  public static void register() {
    CapabilityManager.INSTANCE.register(DankHandler.class, new Capability.IStorage<DankHandler>() {
      @Override
      public NBTBase writeNBT(Capability<DankHandler> cap, DankHandler instance, EnumFacing side) {
        NBTTagList nbtTagList = new NBTTagList();
        for (int i = 0; i < instance.getContents().size(); i++) {
          if (!instance.getContents().get(i).func_190926_b()) {
            int realCount = Math.min(instance.stacklimit, instance.getContents().get(i).func_190916_E());
            NBTTagCompound itemTag = new NBTTagCompound();
            itemTag.func_74768_a("Slot", i);
            instance.getContents().get(i).func_77955_b(itemTag);
            itemTag.func_74768_a("ExtendedCount", realCount);
            nbtTagList.func_74742_a(itemTag);
          }
        }
        NBTTagCompound nbt = new NBTTagCompound();
        nbt.func_74782_a("Items", nbtTagList);
        nbt.func_74768_a("Size", instance.getContents().size());
        return nbt;
      }

      @Override
      public void readNBT(Capability<DankHandler> capability, DankHandler instance, EnumFacing side, NBTBase base) {
        NBTTagCompound nbt = (NBTTagCompound)base;
        instance.setSize(nbt.func_150297_b("Size", Constants.NBT.TAG_INT) ? nbt.func_74762_e("Size") : instance.getContents().size());
        NBTTagList tagList = nbt.func_150295_c("Items", Constants.NBT.TAG_COMPOUND);
        for (int i = 0; i < tagList.func_74745_c(); i++) {
          NBTTagCompound itemTags = tagList.func_150305_b(i);
          int slot = itemTags.func_74762_e("Slot");

          if (slot >= 0 && slot < instance.getContents().size()) {
            if (itemTags.func_150297_b("StackList", Constants.NBT.TAG_LIST)) { // migrate from old ExtendedItemStack system
              ItemStack stack = ItemStack.field_190927_a;
              NBTTagList stackTagList = itemTags.func_150295_c("StackList", Constants.NBT.TAG_COMPOUND);
              for (int j = 0; j < stackTagList.func_74745_c(); j++) {
                NBTTagCompound itemTag = stackTagList.func_150305_b(j);
                ItemStack temp = new ItemStack(itemTag);
                if (!temp.func_190926_b()) {
                  if (stack.func_190926_b()) stack = temp;
                  else stack.func_190917_f(temp.func_190916_E());
                }
              }
              if (!stack.func_190926_b()) {
                int count = stack.func_190916_E();
                count = Math.min(count, instance.getStackLimit(slot, stack));
                stack.func_190920_e(count);

                instance.getContents().set(slot, stack);
              }
            } else {
              ItemStack stack = new ItemStack(itemTags);
              if (itemTags.func_150297_b("ExtendedCount", Constants.NBT.TAG_INT)) {
                stack.func_190920_e(itemTags.func_74762_e("ExtendedCount"));
              }
              instance.getContents().set(slot, stack);
            }
          }
        }
        //instance.onLoad();
      }
    }, () -> null);
  }
}
